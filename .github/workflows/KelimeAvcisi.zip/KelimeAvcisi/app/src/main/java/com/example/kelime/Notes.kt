package com.example.kelime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Notes {
    private fun prefs(c: Context) = c.getSharedPreferences("notes", Context.MODE_PRIVATE)

    fun add(c: Context, word: String, meaning: String) {
        val arr = JSONArray(prefs(c).getString("list", "[]"))
        for (i in 0 until arr.length()) {
            if (arr.getJSONObject(i).getString("w") == word) return // zaten kayıtlı
        }
        arr.put(JSONObject().put("w", word).put("m", meaning))
        prefs(c).edit().putString("list", arr.toString()).apply()
    }

    fun all(c: Context): List<String> {
        val arr = JSONArray(prefs(c).getString("list", "[]"))
        return (arr.length() - 1 downTo 0).map {
            val o = arr.getJSONObject(it)
            "${o.getString("w")}\n${o.getString("m")}"
        }
    }
}
