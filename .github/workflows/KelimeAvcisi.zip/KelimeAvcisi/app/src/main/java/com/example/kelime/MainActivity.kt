package com.example.kelime

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var list: ListView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 32) }
        val btn = Button(this).apply {
            text = "Servisi aç (Erişilebilirlik → Kelime Avcısı)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val title = TextView(this).apply { text = "Notlarım"; textSize = 20f; setPadding(0, 32, 0, 16) }
        list = ListView(this)
        root.addView(btn); root.addView(title); root.addView(list)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, Notes.all(this))
    }
}
