package com.example.kelime

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread

class WordService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var fab: View? = null
    private var overlay: View? = null

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "?"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC6200EE.toInt()) }
            setOnClickListener { capture() }
        }
        val lp = WindowManager.LayoutParams(
            150, 150, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm.addView(b, lp)
        fab = b
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        closeOverlay(); fab?.let { wm.removeView(it) }
        super.onDestroy()
    }

    // 1) Ekran görüntüsü al
    private fun capture() {
        closeOverlay()
        fab?.visibility = View.INVISIBLE
        main.postDelayed({
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    fab?.visibility = View.VISIBLE
                    val bmp = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    r.hardwareBuffer.close()
                    if (bmp != null) recognize(bmp)
                }
                override fun onFailure(code: Int) {
                    fab?.visibility = View.VISIBLE
                    Toast.makeText(this@WordService, "Ekran alınamadı ($code)", Toast.LENGTH_SHORT).show()
                }
            })
        }, 250)
    }

    // 2) OCR ile kelimeleri ve konumlarını bul
    private fun recognize(bmp: Bitmap) {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { t ->
                val words = t.textBlocks.flatMap { it.lines }.flatMap { it.elements }
                    .mapNotNull { e -> e.boundingBox?.let { e.text to it } }
                showOverlay(words)
            }
    }

    // 3) Kelimeleri dokunulabilir yap
    private fun showOverlay(words: List<Pair<String, Rect>>) {
        val card = TextView(this).apply {
            setTextColor(Color.BLACK); textSize = 16f; setPadding(40, 32, 40, 32)
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 32f }
            visibility = View.GONE
        }
        val view = object : View(this) {
            val paint = Paint().apply { style = Paint.Style.STROKE; color = 0xFF6200EE.toInt(); strokeWidth = 3f }
            override fun onDraw(c: Canvas) {
                c.drawColor(0x55000000)
                words.forEach { c.drawRect(it.second, paint) }
            }
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_UP) {
                    val hit = words.firstOrNull { it.second.contains(e.x.toInt(), e.y.toInt()) }
                    if (hit == null) { closeOverlay(); return true }
                    val word = hit.first.trim { !it.isLetter() }.lowercase(Locale("tr"))
                    if (word.isEmpty()) return true
                    card.visibility = View.VISIBLE
                    card.text = "$word\nAranıyor…"
                    lookup(word) { meaning ->
                        card.text = "$word\n$meaning\n\n✓ Notlara kaydedildi"
                        if (meaning != NOT_FOUND) Notes.add(this@WordService, word, meaning)
                    }
                }
                return true
            }
        }
        val root = FrameLayout(this).apply {
            addView(view, FrameLayout.LayoutParams(-1, -1))
            addView(card, FrameLayout.LayoutParams(-1, -2).apply {
                gravity = Gravity.BOTTOM; setMargins(32, 0, 32, 120)
            })
        }
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
        overlay = root
    }

    private fun closeOverlay() {
        overlay?.let { wm.removeView(it) }
        overlay = null
    }

    // 4) TDK sözlüğünden anlam çek (başka sözlük/API için sadece burayı değiştir)
    private fun lookup(word: String, done: (String) -> Unit) {
        thread {
            val meaning = try {
                val c = URL("https://sozluk.gov.tr/gts?ara=" + URLEncoder.encode(word, "UTF-8"))
                    .openConnection() as HttpURLConnection
                val list = JSONArray(c.inputStream.bufferedReader().readText())
                    .getJSONObject(0).getJSONArray("anlamlarListe")
                (0 until minOf(3, list.length()))
                    .joinToString("\n") { "${it + 1}. " + list.getJSONObject(it).getString("anlam") }
            } catch (e: Exception) { NOT_FOUND }
            main.post { done(meaning) }
        }
    }

    companion object { const val NOT_FOUND = "Anlam bulunamadı" }
}
